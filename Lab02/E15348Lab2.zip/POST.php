<html>

<head>
	<style>
		table{
    border: 3px solid black;
	}
	</style>

</head>

<body>
<table align="center" width="600">
<td>
<h1>Your Information System</h1>

<?php

if(isset($_POST["fName"])){
	$Fname = $_POST["fName"];
}else{
	$Fname = " ";
}
if(isset($_POST["lName"])){
	$Lname = $_POST["lName"];
}else{
	$Lname = " ";
}
if(isset($_POST["t_size"])){
	$Size = $_POST["t_size"];
}else{
	$Size = " ";
}
if(isset($_POST["selectCol"])){
	$Color = $_POST["selectCol"];
}else{
	$Color = " ";
}
if(isset($_POST["eItem"])){
	$Cap = $_POST["eItem"];
}else{
	$Cap = " ";
}
if(isset($_POST["wBand"])){
	$Band = $_POST["wBand"];
}else{
	$Band = " ";
}
if(isset($_POST["lName"])){
	$Lname = $_POST["lName"];
}else{
	$Lname = " ";
}
if(isset($_POST["add1"])){
	$Add1 = $_POST["add1"];
}else{
	$Add1 = " ";
}if(isset($_POST["add2"])){
	$Add2 = $_POST["add2"];
}else{
	$Add2 = " ";
}
if(isset($_POST["add3"])){
	$Add3 = $_POST["add3"];
}else{
	$Add3 = " ";
}
if(isset($_POST["comment"])){
	$cmnt = $_POST["comment"];
}else{
	$cmnt = " ";
}


echo "<p>Thank you, $Fname for your purches from our website</p>";
echo "<p>your item colour is : $Color & T-Shirt size : $Size </p>";
echo "Selected item/items are :" ;

	if(isset($_POST["eItem"])){
		echo"<ul><li>$Cap</li></ul>";
	}
	else{
		echo "  ";
	}
	if(isset($_POST["wBand"])){ 
		echo "<ul><li>$Band</li></ul>";
	}
	else{
		echo "  ";
	}

echo "<p>your items will be sent to :</p>";
echo"<i>$Fname $Lname, <br>$Add1, <br>$Add2, <br>$Add3.</i>";

echo"<p>Thank you for submitting your comments. We appreciate it. You said :<br><br><i> $cmnt </i></p><br>";

?>
</td>
</table>
</body>
</html>
