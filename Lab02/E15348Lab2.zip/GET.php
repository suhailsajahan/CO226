<html>

<head>
	<style>
		table{
    border: 3px solid black;
	}
	</style>

</head>

<body>
<table align="center" width="600">
<td>
<h1>Your Information System</h1>

<?php

if(isset($_GET["fName"])){
	$Fname = $_GET["fName"];
}else{
	$Fname = " ";
}
if(isset($_GET["lName"])){
	$Lname = $_GET["lName"];
}else{
	$Lname = " ";
}
if(isset($_GET["t_size"])){
	$Size = $_GET["t_size"];
}else{
	$Size = " ";
}
if(isset($_GET["selectCol"])){
	$Color = $_GET["selectCol"];
}else{
	$Color = " ";
}
if(isset($_GET["eItem"])){
	$Cap = $_GET["eItem"];
}else{
	$Cap = " ";
}
if(isset($_GET["wBand"])){
	$Band = $_GET["wBand"];
}else{
	$Band = " ";
}
if(isset($_GET["lName"])){
	$Lname = $_GET["lName"];
}else{
	$Lname = " ";
}
if(isset($_GET["add1"])){
	$Add1 = $_GET["add1"];
}else{
	$Add1 = " ";
}if(isset($_GET["add2"])){
	$Add2 = $_GET["add2"];
}else{
	$Add2 = " ";
}
if(isset($_GET["add3"])){
	$Add3 = $_GET["add3"];
}else{
	$Add3 = " ";
}
if(isset($_GET["comment"])){
	$cmnt = $_GET["comment"];
}else{
	$cmnt = " ";
}


echo "<p>Thank you, $Fname for your purches from our website</p>";
echo "<p>your item colour is : $Color & T-Shirt size : $Size </p>";
echo "Selected item/items are :" ;

	if(isset($_GET["eItem"])){
		echo"<ul><li>$Cap</li></ul>";
	}
	else{
		echo "  ";
	}
	if(isset($_GET["wBand"])){ 
		echo "<ul><li>$Band</li></ul>";
	}
	else{
		echo "  ";
	}

echo "<p>your items will be sent to :</p>";
echo"<i>$Fname $Lname, <br>$Add1, <br>$Add2, <br>$Add3.</i>";

echo"<p>Thank you for submitting your comments. We appreciate it. You said :<br><br><i> $cmnt </i></p><br>";

?>
</td>
</table>
</body>
</html>
